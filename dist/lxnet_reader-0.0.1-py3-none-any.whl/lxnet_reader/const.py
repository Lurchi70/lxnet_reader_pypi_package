"""Constants for lxnet_reader package"""
from __future__ import absolute_import

# Default config for LX NET Device.
DEVICE_MANUFACTURER = "TECSON"
DEFAULT_MODEL = "TankSpion LX-Net"

